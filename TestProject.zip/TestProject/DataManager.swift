

import Foundation

enum DataManagerError: Error {
    
    case unknown
    case failedRequest
    case invalidResponse
}

final class DataManager {
    
    var ObjectArray = [ViemoData]()
    var dataObjectViemo:ViemoData?
    
    typealias ViemDataCompletion = ( [ViemoData]?, DataManagerError?) -> ()

    // MARK: - Properties

    private let baseURL: URL

    // MARK: - Initialization

    init(baseURL: URL) {
        self.baseURL = baseURL
    }

    // MARK: - Requesting Data

    func viemoDataForAlbumId(pageNo:Int, completion: @escaping ViemDataCompletion) {
        let URL = baseURL

        // Create Data Task
        URLSession.shared.dataTask(with: URL) { (data, response, error) in
            DispatchQueue.main.async {
                self.didFetchViemoData(data: data, response: response, error: error, completion: completion)
            }
        }.resume()
    }

    // MARK: - Helper Methods

    private func didFetchViemoData(data: Data?, response: URLResponse?, error: Error?, completion: ViemDataCompletion) {
        if let _ = error {
            completion(nil, .failedRequest)

        } else if let data = data, let response = response as? HTTPURLResponse {
            if response.statusCode == 200 {
                do {
                    // Decode JSON
                    let dictJSon = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves)
                        for object in (dictJSon as? [[String:Any]])! {
                            
                            dataObjectViemo = ViemoData(time: (object["upload_date"]! as? String)! , title : (object["title"]! as? String)!, description: (object["description"]! as? String)!, userName: (object["user_name"]! as? String)!, icon: (object["thumbnail_small"]! as? String)!)
                        
                        ObjectArray.append(dataObjectViemo!)
                    }
                    
                    // Invoke Completion Handler
                    completion(ObjectArray, nil)

                } catch {
                    // Invoke Completion Handler
                    completion(nil, .invalidResponse)
                }

            } else {
                completion(nil, .failedRequest)
            }

        } else {
            completion(nil, .unknown)
        }
    }

}
