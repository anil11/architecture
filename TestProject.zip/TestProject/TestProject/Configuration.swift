//
//  Configuration.swift
//  TestProject
//
//  Created by Anil on 11/05/17.
//  Copyright © 2017 Anil. All rights reserved.
//

import Foundation

struct API {
    
    static let BaseURL = URL(string:"http://vimeo.com/api/v2/album/58/videos.json?page=1")
    
    static var AuthenticatedBaseURL: URL {
        
        return BaseURL!
    }
}
