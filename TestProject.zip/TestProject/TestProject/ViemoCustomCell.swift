//
//  ViemoCustomCell.swift
//  TestProject
//
//  Created by Anil on 12/05/17.
//  Copyright © 2017 Anil. All rights reserved.
//

import UIKit

class ViemoCustomCell: UITableViewCell {

    // MARK: - Properties
    
    @IBOutlet var titleLabel: UILabel?
    @IBOutlet var userNameLabel: UILabel?
    @IBOutlet var dateLabel: UILabel?
    @IBOutlet var iconImageView: UIImageView?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Configure Cell
        selectionStyle = .none
    }
}
