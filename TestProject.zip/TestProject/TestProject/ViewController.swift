//
//  ViewController.swift
//  TestProject
//
//  Created by Anil on 11/05/17.
//  Copyright © 2017 Anil. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
    
   @IBOutlet var viemoTable: UITableView!

    var ObjectArray = [ViemoData]()

    fileprivate lazy var dataManager = {
        return DataManager(baseURL: API.AuthenticatedBaseURL)
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
         fetchViemoData()
    }
    
    fileprivate func fetchViemoData() {
        dataManager.viemoDataForAlbumId(pageNo: 1) { (response, error) in
            if let error = error {
                print(error)
            } else if let response = response {
                self.ObjectArray=response
                DispatchQueue.main.async{
                    self.viemoTable.reloadData()
                }
            }
        }
    }
    
    private func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return ObjectArray.count
    }

     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.viemoTable.dequeueReusableCell(withIdentifier:"cellidentifire" , for: indexPath) as? ViemoCustomCell else { fatalError("Unexpected Table View Cell") }
       
        let viemoatIndexData = ObjectArray[indexPath.row]
        cell.titleLabel?.text = viemoatIndexData.title
        cell.dateLabel?.text = viemoatIndexData.time
        cell.userNameLabel?.text = viemoatIndexData.userName
        cell.iconImageView?.downloadedFrom(link: viemoatIndexData.icon)
        return cell
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

