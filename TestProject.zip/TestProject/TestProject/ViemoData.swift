//
//  ViemoData.swift
//  TestProject
//
//  Created by Anil on 11/05/17.
//  Copyright © 2017 Anil. All rights reserved.
//

import Foundation

struct ViemoData {
    
    let time: String
    let title: String
    let description: String
    let userName: String
    let icon: String
    

   init(time: String , title : String, description: String, userName: String, icon: String)  {
        
        self.title = title
        self.description = description
        self.icon = icon
        self.userName = userName
        self.time = time
    }
}
